

def check_args():
    pass